# Crea un acceso directo en la carpeta de Inicio de Windows para que
# MidiShortcuts arranque solo, en segundo plano, al encender el PC.
#
# Uso: click derecho -> "Ejecutar con PowerShell" (o correrlo desde una
# terminal de PowerShell) estando en la misma carpeta que MidiShortcuts.exe.

$exePath = Join-Path $PSScriptRoot "MidiShortcuts.exe"
if (-not (Test-Path $exePath)) {
    Write-Host "No se encontro MidiShortcuts.exe en esta carpeta: $exePath" -ForegroundColor Red
    exit 1
}

$startupFolder = [Environment]::GetFolderPath("Startup")
$shortcutPath = Join-Path $startupFolder "MidiShortcuts.lnk"

$WScriptShell = New-Object -ComObject WScript.Shell
$shortcut = $WScriptShell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $exePath
$shortcut.Arguments = "--background"
$shortcut.WorkingDirectory = $PSScriptRoot
$shortcut.WindowStyle = 7  # minimizado
$shortcut.Description = "MIDI Shortcuts - Starrypad mini (segundo plano)"
$shortcut.Save()

Write-Host "Listo. Acceso directo creado en: $shortcutPath"
Write-Host "Se ejecutara 'MidiShortcuts.exe --background' cada vez que inicies sesion en Windows."
